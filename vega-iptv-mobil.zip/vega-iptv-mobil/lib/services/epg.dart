/// XMLTV bicimindeki yayin akisinin indirilmesi ve okunmasi.

import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:xml/xml_events.dart';

import '../models/models.dart';

/// '20260908183000 +0300' bicimini DateTime'a cevirir.
DateTime? parseXmltvTime(String? value) {
  if (value == null) return null;
  final text = value.trim();
  if (text.length < 12) return null;

  final base = text.length >= 14 ? text.substring(0, 14) : '${text.substring(0, 12)}00';
  int? number(int start, int end) => int.tryParse(base.substring(start, end));

  final year = number(0, 4);
  final month = number(4, 6);
  final day = number(6, 8);
  final hour = number(8, 10);
  final minute = number(10, 12);
  final second = number(12, 14) ?? 0;
  if (year == null || month == null || day == null || hour == null || minute == null) {
    return null;
  }

  var moment = DateTime.utc(year, month, day, hour, minute, second);

  final offset = text.length > 14 ? text.substring(14).trim() : '';
  if (offset.length >= 5 && (offset[0] == '+' || offset[0] == '-')) {
    final hours = int.tryParse(offset.substring(1, 3)) ?? 0;
    final minutes = int.tryParse(offset.substring(3, 5)) ?? 0;
    final shift = Duration(hours: hours, minutes: minutes);
    moment = offset[0] == '+' ? moment.subtract(shift) : moment.add(shift);
  }
  return moment.toLocal();
}

class EpgData {
  final Map<String, List<Programme>> byChannel = {};
  final Map<String, String> displayNames = {};

  bool get isEmpty => byChannel.isEmpty;
  bool get isNotEmpty => byChannel.isNotEmpty;

  /// Kanal kimligini bulamazsa ada gore eslestirmeyi dener.
  String resolveId(Channel channel) {
    if (channel.tvgId.isNotEmpty && byChannel.containsKey(channel.tvgId)) {
      return channel.tvgId;
    }
    final target = _normalize(channel.name);
    for (final entry in displayNames.entries) {
      if (_normalize(entry.value) == target) return entry.key;
    }
    return '';
  }

  (Programme?, Programme?) nowNext(String channelId) {
    final items = byChannel[channelId];
    if (items == null || items.isEmpty) return (null, null);
    final now = DateTime.now();
    Programme? current;
    Programme? upcoming;
    for (final programme in items) {
      if (programme.isLive(now)) {
        current = programme;
      } else if (programme.start.isAfter(now)) {
        upcoming = programme;
        break;
      }
    }
    return (current, upcoming);
  }

  List<Programme> upcoming(String channelId, {int limit = 40}) {
    final items = byChannel[channelId];
    if (items == null) return const [];
    final now = DateTime.now();
    final result = items.where((p) => p.stop.isAfter(now)).toList();
    return result.length > limit ? result.sublist(0, limit) : result;
  }

  void merge(EpgData other) {
    other.byChannel.forEach((key, value) {
      byChannel.putIfAbsent(key, () => <Programme>[]).addAll(value);
    });
    displayNames.addAll(other.displayNames);
    for (final list in byChannel.values) {
      list.sort((a, b) => a.start.compareTo(b.start));
    }
  }
}

String _normalize(String value) => value
    .toLowerCase()
    .replaceAll('ı', 'i')
    .replaceAll('ğ', 'g')
    .replaceAll('ü', 'u')
    .replaceAll('ş', 's')
    .replaceAll('ö', 'o')
    .replaceAll('ç', 'c')
    .replaceAll(RegExp(r'[^a-z0-9]'), '');

/// XMLTV metnini olay akisi olarak okur; buyuk dosyalarda bellegi korur.
EpgData parseXmltv(String text) {
  final epg = EpgData();

  String? currentChannelId;
  String? programmeChannel;
  DateTime? programmeStart;
  DateTime? programmeStop;
  String? capturing;
  final buffer = StringBuffer();
  String programmeTitle = '';
  String programmeDesc = '';

  for (final event in parseEvents(text)) {
    if (event is XmlStartElementEvent) {
      switch (event.name) {
        case 'channel':
          currentChannelId = _attribute(event, 'id');
          break;
        case 'programme':
          programmeChannel = _attribute(event, 'channel');
          programmeStart = parseXmltvTime(_attribute(event, 'start'));
          programmeStop = parseXmltvTime(_attribute(event, 'stop'));
          programmeTitle = '';
          programmeDesc = '';
          break;
        case 'display-name':
        case 'title':
        case 'desc':
          if (!event.isSelfClosing) {
            capturing = event.name;
            buffer.clear();
          }
          break;
      }
    } else if (event is XmlTextEvent || event is XmlCDATAEvent) {
      if (capturing != null) {
        buffer.write(event is XmlTextEvent
            ? event.value
            : (event as XmlCDATAEvent).value);
      }
    } else if (event is XmlEndElementEvent) {
      switch (event.name) {
        case 'display-name':
          if (capturing == 'display-name' &&
              currentChannelId != null &&
              currentChannelId.isNotEmpty) {
            epg.displayNames.putIfAbsent(
                currentChannelId, () => buffer.toString().trim());
          }
          capturing = null;
          break;
        case 'title':
          if (capturing == 'title') programmeTitle = buffer.toString().trim();
          capturing = null;
          break;
        case 'desc':
          if (capturing == 'desc') programmeDesc = buffer.toString().trim();
          capturing = null;
          break;
        case 'channel':
          currentChannelId = null;
          break;
        case 'programme':
          final id = programmeChannel;
          final start = programmeStart;
          final stop = programmeStop;
          if (id != null && id.isNotEmpty && start != null && stop != null) {
            epg.byChannel.putIfAbsent(id, () => <Programme>[]).add(Programme(
                  channelId: id,
                  start: start,
                  stop: stop,
                  title: programmeTitle.isEmpty ? 'Program' : programmeTitle,
                  description: programmeDesc,
                ));
          }
          programmeChannel = null;
          programmeStart = null;
          programmeStop = null;
          break;
      }
    }
  }

  for (final list in epg.byChannel.values) {
    list.sort((a, b) => a.start.compareTo(b.start));
  }
  return epg;
}

String? _attribute(XmlStartElementEvent event, String name) {
  for (final attribute in event.attributes) {
    if (attribute.name == name) return attribute.value;
  }
  return null;
}

/// EPG dosyasini indirir ve duz metin olarak dondurur; gzip ile
/// sikistirilmis dosyalari acar. Ayristirma ayri bir isolate'te yapilsin
/// diye indirme ile ayristirma bilerek ayrilmistir.
Future<String> downloadEpgText(String url, {String userAgent = ''}) async {
  final response = await http.get(
    Uri.parse(url),
    headers: {'User-Agent': userAgent.isEmpty ? 'VLC/3.0.20' : userAgent},
  ).timeout(const Duration(seconds: 60));

  if (response.statusCode != 200) {
    throw Exception('Yayın akışı alınamadı (${response.statusCode}).');
  }

  final raw = response.bodyBytes;
  // gzip imzasi (1f 8b) varsa dosya sikistirilmistir
  final List<int> bytes =
      (raw.length > 2 && raw[0] == 0x1f && raw[1] == 0x8b) ? gzip.decode(raw) : raw;
  return utf8.decode(bytes, allowMalformed: true);
}
