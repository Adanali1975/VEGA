/// M3U ayristirma ve Xtream Codes destegi.
///
/// Masaustu surumundeki playlist.py'nin Dart karsiligi.

import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/models.dart';

const String defaultUserAgent = 'VLC/3.0.20 LibVLC/3.0.20';
const Duration requestTimeout = Duration(seconds: 25);

final RegExp _attributePattern = RegExp(r'([A-Za-z0-9\-_]+)\s*=\s*"([^"]*)"');

/// Bir M3U/M3U8 metnini kanal listesine cevirir.
List<Channel> parseM3u(String text, {Source? source}) {
  final channels = <Channel>[];
  final sourceId = source?.id ?? '';
  final sourceName = source?.name ?? '';

  String pendingName = '';
  String pendingGroup = 'Diğer';
  String pendingLogo = '';
  String pendingTvgId = '';
  bool hasPending = false;

  void resetPending() {
    pendingName = '';
    pendingGroup = 'Diğer';
    pendingLogo = '';
    pendingTvgId = '';
    hasPending = false;
  }

  for (final rawLine in const LineSplitter().convert(text)) {
    final line = rawLine.trim();
    if (line.isEmpty) continue;

    final upper = line.toUpperCase();

    if (upper.startsWith('#EXTINF')) {
      final info = line.contains(':') ? line.split(':').sublist(1).join(':') : '';
      final attributes = <String, String>{};
      for (final match in _attributePattern.allMatches(info)) {
        attributes[match.group(1)!.toLowerCase()] = match.group(2) ?? '';
      }
      // Kanal adi, oznitelik bolumunden sonraki ILK virgulden sonra gelir.
      // Son virgule bakmak "BBC One, London" gibi virgullu adlari boler;
      // ilk virgule bakmak ise oznitelik degeri icindeki virgullere takilir.
      // Bu yuzden aramaya son tirnaktan sonra baslanir.
      var searchFrom = 0;
      final lastQuote = info.lastIndexOf('"');
      if (lastQuote >= 0) searchFrom = lastQuote + 1;
      final commaIndex = info.indexOf(',', searchFrom);
      var name = '';
      if (commaIndex >= 0 && commaIndex + 1 < info.length) {
        name = info.substring(commaIndex + 1).trim();
      }
      if (name.isEmpty) name = attributes['tvg-name'] ?? 'İsimsiz kanal';

      pendingName = name;
      pendingGroup = attributes['group-title']?.trim().isNotEmpty == true
          ? attributes['group-title']!.trim()
          : 'Diğer';
      pendingLogo = attributes['tvg-logo'] ?? '';
      pendingTvgId = attributes['tvg-id'] ?? '';
      hasPending = true;
    } else if (upper.startsWith('#EXTGRP')) {
      if (hasPending && line.contains(':')) {
        final group = line.split(':').sublist(1).join(':').trim();
        if (group.isNotEmpty) pendingGroup = group;
      }
    } else if (line.startsWith('#')) {
      continue;
    } else {
      // Adres satiri: bekleyen basligi tamamlar
      if (!hasPending) {
        pendingName = _nameFromUrl(line);
        pendingGroup = 'Diğer';
      }
      channels.add(Channel(
        name: pendingName,
        url: line,
        group: pendingGroup,
        logo: pendingLogo,
        tvgId: pendingTvgId,
        sourceId: sourceId,
        sourceName: sourceName,
      ));
      resetPending();
    }
  }

  return channels;
}

String _nameFromUrl(String url) {
  try {
    final path = Uri.parse(url).path;
    final parts = path.split('/').where((part) => part.isNotEmpty).toList();
    if (parts.isEmpty) return url;
    final segment = parts.last;
    final dot = segment.lastIndexOf('.');
    return dot > 0 ? segment.substring(0, dot) : segment;
  } catch (_) {
    return url.length > 40 ? url.substring(0, 40) : url;
  }
}

/// Sunucudan duz metin indirir.
Future<String> fetchText(String url, {String userAgent = defaultUserAgent}) async {
  final response = await http
      .get(Uri.parse(url), headers: {'User-Agent': userAgent})
      .timeout(requestTimeout);
  if (response.statusCode != 200) {
    throw PlaylistException(_explainStatus(response.statusCode));
  }
  return utf8.decode(response.bodyBytes, allowMalformed: true);
}

/// Xtream Codes panelleri icin ince istemci.
class XtreamClient {
  XtreamClient({
    required String host,
    required this.username,
    required this.password,
    this.userAgent = defaultUserAgent,
    this.useHls = true,
  }) : host = _normalizeHost(host);

  final String host;
  final String username;
  final String password;
  final String userAgent;

  /// true ise kanal adresleri .m3u8 (HLS), false ise .ts olarak uretilir.
  /// HLS mobil aglarda daha kararlidir; bazi paneller yalnizca TS verir.
  final bool useHls;

  static String _normalizeHost(String value) {
    var host = value.trim();
    while (host.endsWith('/')) {
      host = host.substring(0, host.length - 1);
    }
    if (!host.startsWith('http://') && !host.startsWith('https://')) {
      host = 'http://$host';
    }
    return host;
  }

  Uri _apiUri(String action) => Uri.parse('$host/player_api.php').replace(
        queryParameters: {
          'username': username,
          'password': password,
          'action': action,
        },
      );

  Future<dynamic> _call(String action) async {
    final response = await http
        .get(_apiUri(action), headers: {'User-Agent': userAgent})
        .timeout(requestTimeout);
    if (response.statusCode != 200) {
      throw PlaylistException(_explainStatus(response.statusCode));
    }
    try {
      return jsonDecode(utf8.decode(response.bodyBytes, allowMalformed: true));
    } catch (_) {
      throw PlaylistException(
        'Sunucu beklenen yanıtı vermedi. Adres bir Xtream paneli olmayabilir.',
      );
    }
  }

  Future<List<Channel>> liveChannels(Source source) async {
    final categories = <String, String>{};
    try {
      final raw = await _call('get_live_categories');
      if (raw is List) {
        for (final item in raw) {
          if (item is Map) {
            categories['${item['category_id']}'] =
                (item['category_name'] ?? 'Diğer').toString();
          }
        }
      }
    } catch (_) {
      // Kategoriler alinamazsa kanallar yine listelenir
    }

    final raw = await _call('get_live_streams');
    if (raw is! List) {
      throw PlaylistException('Kanal listesi okunamadı.');
    }

    final extension = useHls ? 'm3u8' : 'ts';
    final channels = <Channel>[];
    for (final item in raw) {
      if (item is! Map) continue;
      final streamId = item['stream_id'];
      if (streamId == null) continue;
      channels.add(Channel(
        name: (item['name'] ?? 'Kanal $streamId').toString(),
        url: '$host/live/$username/$password/$streamId.$extension',
        group: categories['${item['category_id']}'] ?? 'Diğer',
        logo: (item['stream_icon'] ?? '').toString(),
        tvgId: (item['epg_channel_id'] ?? '').toString(),
        sourceId: source.id,
        sourceName: source.name,
      ));
    }
    return channels;
  }
}

/// Bir kaynagin kanallarini indirir.
Future<List<Channel>> loadSource(
  Source source, {
  String userAgent = defaultUserAgent,
  bool useHls = true,
}) async {
  if (source.kind == SourceKind.xtream) {
    final client = XtreamClient(
      host: source.url,
      username: source.username,
      password: source.password,
      userAgent: userAgent,
      useHls: useHls,
    );
    return client.liveChannels(source);
  }
  final text = await fetchText(source.url, userAgent: userAgent);
  final channels = parseM3u(text, source: source);
  if (channels.isEmpty) {
    throw PlaylistException('Liste boş görünüyor, hiç kanal bulunamadı.');
  }
  return channels;
}

String _explainStatus(int status) {
  switch (status) {
    case 401:
      return 'Sunucu kimlik doğrulama istedi. Kullanıcı adı ve parolayı kontrol edin.';
    case 403:
      return 'Sunucu erişimi reddetti (403). Abonelik geçersiz olabilir.';
    case 404:
      return 'Adres bulunamadı (404).';
    default:
      return 'Sunucu $status yanıtı verdi.';
  }
}

class PlaylistException implements Exception {
  PlaylistException(this.message);
  final String message;
  @override
  String toString() => message;
}
