/// Uygulamanin tek durum kaynagi.
///
/// Kaynaklar, indirilen kanallar, favoriler, ayarlar ve yayin akisi burada
/// tutulur. Arayuz bu nesneyi dinler (ChangeNotifier), boylece ayri bir
/// durum yonetimi paketine gerek kalmaz.

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../models/models.dart';
import 'epg.dart';
import 'playlist.dart';

class Settings {
  Settings({
    this.userAgent = defaultUserAgent,
    this.useHls = true,
    this.backgroundAudio = true,
    this.rememberLastChannel = true,
  });

  String userAgent;

  /// Xtream kanallari .m3u8 (HLS) olarak istensin mi? Kapaliysa .ts kullanilir.
  bool useHls;
  bool backgroundAudio;
  bool rememberLastChannel;

  Map<String, dynamic> toJson() => {
        'userAgent': userAgent,
        'useHls': useHls,
        'backgroundAudio': backgroundAudio,
        'rememberLastChannel': rememberLastChannel,
      };

  factory Settings.fromJson(Map<String, dynamic> json) => Settings(
        userAgent: (json['userAgent'] ?? defaultUserAgent) as String,
        useHls: (json['useHls'] ?? true) as bool,
        backgroundAudio: (json['backgroundAudio'] ?? true) as bool,
        rememberLastChannel: (json['rememberLastChannel'] ?? true) as bool,
      );
}

class Library extends ChangeNotifier {
  Library._();
  static final Library instance = Library._();

  final List<Source> sources = [];
  final Map<String, List<Channel>> channelsBySource = {};
  final Set<String> favorites = {};
  final EpgData epg = EpgData();
  Settings settings = Settings();

  String lastChannelKey = '';
  String? activeSourceId; // null = tüm listeler
  String searchText = '';
  String groupFilter = '';
  bool favoritesOnly = false;

  bool busy = false;
  String status = '';

  Directory? _directory;

  // ---------------------------------------------------------------
  // Disk
  // ---------------------------------------------------------------

  Future<Directory> _dir() async {
    _directory ??= await getApplicationDocumentsDirectory();
    return _directory!;
  }

  Future<File> _file(String name) async => File('${(await _dir()).path}/$name');

  Future<void> load() async {
    try {
      final file = await _file('config.json');
      if (await file.exists()) {
        final data = jsonDecode(await file.readAsString());
        if (data is Map<String, dynamic>) {
          settings = Settings.fromJson(
              (data['settings'] as Map?)?.cast<String, dynamic>() ?? {});
          sources
            ..clear()
            ..addAll(((data['sources'] as List?) ?? [])
                .whereType<Map>()
                .map((m) => Source.fromJson(m.cast<String, dynamic>())));
          favorites
            ..clear()
            ..addAll(((data['favorites'] as List?) ?? []).map((e) => '$e'));
          lastChannelKey = (data['lastChannel'] ?? '') as String;
        }
      }
    } catch (_) {
      // Bozuk yapilandirma uygulamayi engellemesin
    }

    for (final source in sources) {
      final cached = await _readCache(source.id);
      if (cached.isNotEmpty) channelsBySource[source.id] = cached;
    }
    notifyListeners();
  }

  Future<void> save() async {
    try {
      final file = await _file('config.json');
      await file.writeAsString(jsonEncode({
        'settings': settings.toJson(),
        'sources': sources.map((s) => s.toJson()).toList(),
        'favorites': favorites.toList(),
        'lastChannel': lastChannelKey,
      }));
    } catch (_) {}
  }

  Future<List<Channel>> _readCache(String sourceId) async {
    try {
      final file = await _file('channels_$sourceId.json');
      if (!await file.exists()) return const [];
      final data = jsonDecode(await file.readAsString());
      if (data is! List) return const [];
      return data
          .whereType<Map>()
          .map((m) => Channel.fromJson(m.cast<String, dynamic>()))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  Future<void> _writeCache(String sourceId, List<Channel> channels) async {
    try {
      final file = await _file('channels_$sourceId.json');
      await file.writeAsString(
          jsonEncode(channels.map((c) => c.toJson()).toList()));
    } catch (_) {}
  }

  // ---------------------------------------------------------------
  // Kaynaklar
  // ---------------------------------------------------------------

  Future<void> addSource(Source source) async {
    sources.add(source);
    await save();
    notifyListeners();
    await refreshSource(source);
  }

  Future<void> removeSource(String sourceId) async {
    sources.removeWhere((s) => s.id == sourceId);
    channelsBySource.remove(sourceId);
    if (activeSourceId == sourceId) activeSourceId = null;
    try {
      final file = await _file('channels_$sourceId.json');
      if (await file.exists()) await file.delete();
    } catch (_) {}
    await save();
    notifyListeners();
  }

  Future<void> refreshSource(Source source) async {
    busy = true;
    status = '${source.name} yükleniyor…';
    notifyListeners();
    try {
      final channels = await loadSource(
        source,
        userAgent: settings.userAgent,
        useHls: settings.useHls,
      );
      channelsBySource[source.id] = channels;
      await _writeCache(source.id, channels);
      status = '${source.name}: ${channels.length} kanal';
    } on PlaylistException catch (error) {
      status = '${source.name}: ${error.message}';
    } catch (error) {
      status = '${source.name} yüklenemedi: $error';
    } finally {
      busy = false;
      notifyListeners();
    }

    if (source.epgUrl.isNotEmpty) {
      await refreshEpg(source.epgUrl);
    }
  }

  Future<void> refreshAll() async {
    for (final source in sources) {
      await refreshSource(source);
    }
  }

  Future<void> refreshEpg(String url) async {
    try {
      final text = await downloadEpgText(url, userAgent: settings.userAgent);
      if (text.isEmpty) return;
      // Ayristirma ayri bir isolate'te: EPG dosyalari on megabayti
      // bulabilir, ana is parcaciginda yapilirsa arayuz donar.
      final data = await compute(parseXmltvInIsolate, text);
      epg.merge(data);
      notifyListeners();
    } catch (_) {
      // Yayin akisi alinamasa da uygulama calismaya devam eder
    }
  }

  // ---------------------------------------------------------------
  // Filtreleme
  // ---------------------------------------------------------------

  List<Channel> get allChannels {
    if (activeSourceId != null) {
      return channelsBySource[activeSourceId] ?? const [];
    }
    final result = <Channel>[];
    for (final source in sources) {
      result.addAll(channelsBySource[source.id] ?? const []);
    }
    return result;
  }

  List<String> get groups {
    final seen = <String>{};
    for (final channel in allChannels) {
      seen.add(channel.group);
    }
    final list = seen.toList()..sort((a, b) => _fold(a).compareTo(_fold(b)));
    return list;
  }

  List<Channel> get visibleChannels {
    final terms = _fold(searchText).split(' ').where((t) => t.isNotEmpty).toList();
    return allChannels.where((channel) {
      if (groupFilter.isNotEmpty && channel.group != groupFilter) return false;
      if (favoritesOnly && !favorites.contains(channel.key)) return false;
      if (terms.isEmpty) return true;
      final haystack = '${_fold(channel.name)} ${_fold(channel.group)}';
      return terms.every(haystack.contains);
    }).toList();
  }

  void setSearch(String value) {
    searchText = value;
    notifyListeners();
  }

  void setGroup(String value) {
    groupFilter = value;
    notifyListeners();
  }

  void setFavoritesOnly(bool value) {
    favoritesOnly = value;
    notifyListeners();
  }

  void setActiveSource(String? sourceId) {
    activeSourceId = sourceId;
    groupFilter = '';
    notifyListeners();
  }

  bool isFavorite(Channel channel) => favorites.contains(channel.key);

  Future<void> toggleFavorite(Channel channel) async {
    if (!favorites.remove(channel.key)) favorites.add(channel.key);
    notifyListeners();
    await save();
  }

  Future<void> rememberChannel(Channel channel) async {
    lastChannelKey = channel.key;
    await save();
  }

  Channel? get lastChannel {
    if (lastChannelKey.isEmpty) return null;
    for (final channel in allChannels) {
      if (channel.key == lastChannelKey) return channel;
    }
    return null;
  }
}

/// Turkce harfleri de dogru kucultup aramayi kolaylastirir.
String _fold(String value) => value
    .toLowerCase()
    .replaceAll('ı', 'i')
    .replaceAll('İ', 'i')
    .replaceAll('ğ', 'g')
    .replaceAll('ü', 'u')
    .replaceAll('ş', 's')
    .replaceAll('ö', 'o')
    .replaceAll('ç', 'c');

/// compute() icin ust duzey fonksiyon gereklidir.
EpgData parseXmltvInIsolate(String text) => parseXmltv(text);
