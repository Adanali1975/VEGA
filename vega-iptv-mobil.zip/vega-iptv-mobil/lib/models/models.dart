/// Kanal, kaynak ve yayin akisi veri modelleri.
///
/// Masaustu surumundeki models.py ile ayni alanlari tasir; boylece iki
/// uygulama ayni M3U ve Xtream mantigini paylasir.

class Channel {
  const Channel({
    required this.name,
    required this.url,
    this.group = 'Diğer',
    this.logo = '',
    this.tvgId = '',
    this.sourceId = '',
    this.sourceName = '',
  });

  final String name;
  final String url;
  final String group;
  final String logo;
  final String tvgId;
  final String sourceId;
  final String sourceName;

  /// Favori kaydi icin benzersiz anahtar.
  String get key => '$name::$url';

  Map<String, dynamic> toJson() => {
        'name': name,
        'url': url,
        'group': group,
        'logo': logo,
        'tvgId': tvgId,
        'sourceId': sourceId,
        'sourceName': sourceName,
      };

  factory Channel.fromJson(Map<String, dynamic> json) => Channel(
        name: (json['name'] ?? 'İsimsiz kanal') as String,
        url: (json['url'] ?? '') as String,
        group: (json['group'] ?? 'Diğer') as String,
        logo: (json['logo'] ?? '') as String,
        tvgId: (json['tvgId'] ?? '') as String,
        sourceId: (json['sourceId'] ?? '') as String,
        sourceName: (json['sourceName'] ?? '') as String,
      );
}

enum SourceKind { m3u, xtream }

class Source {
  Source({
    required this.id,
    required this.name,
    this.kind = SourceKind.m3u,
    this.url = '',
    this.username = '',
    this.password = '',
    this.epgUrl = '',
  });

  final String id;
  String name;
  SourceKind kind;
  String url;
  String username;
  String password;
  String epgUrl;

  String get description =>
      kind == SourceKind.xtream ? 'Xtream · $url' : 'M3U · $url';

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'kind': kind.name,
        'url': url,
        'username': username,
        'password': password,
        'epgUrl': epgUrl,
      };

  factory Source.fromJson(Map<String, dynamic> json) => Source(
        id: (json['id'] ?? '') as String,
        name: (json['name'] ?? 'Liste') as String,
        kind: (json['kind'] == 'xtream') ? SourceKind.xtream : SourceKind.m3u,
        url: (json['url'] ?? '') as String,
        username: (json['username'] ?? '') as String,
        password: (json['password'] ?? '') as String,
        epgUrl: (json['epgUrl'] ?? '') as String,
      );
}

class Programme {
  const Programme({
    required this.channelId,
    required this.start,
    required this.stop,
    required this.title,
    this.description = '',
  });

  final String channelId;
  final DateTime start;
  final DateTime stop;
  final String title;
  final String description;

  bool isLive(DateTime now) => !now.isBefore(start) && now.isBefore(stop);

  /// 0 ile 1 arasinda ilerleme; program su an oynamiyorsa null.
  double? progress(DateTime now) {
    if (!isLive(now)) return null;
    final total = stop.difference(start).inSeconds;
    if (total <= 0) return null;
    return now.difference(start).inSeconds / total;
  }
}
