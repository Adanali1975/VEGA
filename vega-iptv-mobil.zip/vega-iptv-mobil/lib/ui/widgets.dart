/// Kanal satiri, logo kutusu ve bos durum gorunumleri.

import 'package:flutter/material.dart';

import '../models/models.dart';
import '../services/library.dart';
import 'theme.dart';

class ChannelLogo extends StatelessWidget {
  const ChannelLogo({super.key, required this.channel, this.size = 48});

  final Channel channel;
  final double size;

  @override
  Widget build(BuildContext context) {
    final initials = channel.name
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .take(2)
        .map((part) => part[0].toUpperCase())
        .join();

    final fallback = Container(
      width: size,
      height: size * 0.72,
      decoration: BoxDecoration(
        border: Border.all(color: kBorder),
        borderRadius: BorderRadius.circular(6),
      ),
      alignment: Alignment.center,
      child: Text(
        initials.isEmpty ? 'TV' : initials,
        style: const TextStyle(
          color: kTextDim,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );

    if (channel.logo.isEmpty) return fallback;

    return SizedBox(
      width: size,
      height: size * 0.72,
      child: Image.network(
        channel.logo,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (context, child, progress) =>
            progress == null ? child : fallback,
      ),
    );
  }
}

class ChannelTile extends StatelessWidget {
  const ChannelTile({
    super.key,
    required this.channel,
    required this.onTap,
    this.playing = false,
  });

  final Channel channel;
  final VoidCallback onTap;
  final bool playing;

  @override
  Widget build(BuildContext context) {
    final library = Library.instance;
    final favorite = library.isFavorite(channel);

    String subtitle = channel.group;
    final epgId = library.epg.isNotEmpty ? library.epg.resolveId(channel) : '';
    if (epgId.isNotEmpty) {
      final (current, _) = library.epg.nowNext(epgId);
      if (current != null) subtitle = current.title;
    }

    return InkWell(
      onTap: onTap,
      onLongPress: () => library.toggleFavorite(channel),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
              color: playing ? kAccent : Colors.transparent,
              width: 3,
            ),
          ),
        ),
        child: Row(
          children: [
            ChannelLogo(channel: channel),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    channel.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: playing ? kAccent : kText,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: kTextDim),
                  ),
                ],
              ),
            ),
            if (favorite)
              const Padding(
                padding: EdgeInsets.only(left: 8),
                child: Icon(Icons.star_rounded, color: kAccent, size: 18),
              ),
          ],
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.action,
  });

  final IconData icon;
  final String title;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: kTextDim),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: kTextDim, height: 1.4),
            ),
            if (action != null) ...[
              const SizedBox(height: 20),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}
