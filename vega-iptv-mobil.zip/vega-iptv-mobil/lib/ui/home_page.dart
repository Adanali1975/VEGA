/// Ana ekran: kanal arama, kategori süzme, favoriler.

import 'package:flutter/material.dart';

import '../models/models.dart';
import '../services/library.dart';
import 'player_page.dart';
import 'settings_page.dart';
import 'sources_page.dart';
import 'theme.dart';
import 'widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _library = Library.instance;
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _openChannel(Channel channel) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => PlayerPage(channel: channel)),
    );
  }

  Future<void> _openSources() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const SourcesPage()),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _library,
      builder: (context, _) {
        final hasSources = _library.sources.isNotEmpty;
        final channels = _library.visibleChannels;

        return Scaffold(
          appBar: AppBar(
            title: const Text('Vega IPTV'),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh_rounded),
                tooltip: 'Listeleri yenile',
                onPressed: _library.busy ? null : () => _library.refreshAll(),
              ),
              IconButton(
                icon: const Icon(Icons.playlist_add_rounded),
                tooltip: 'Listelerim',
                onPressed: _openSources,
              ),
              IconButton(
                icon: const Icon(Icons.settings_rounded),
                tooltip: 'Ayarlar',
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const SettingsPage()),
                ),
              ),
            ],
            bottom: _library.busy
                ? const PreferredSize(
                    preferredSize: Size.fromHeight(2),
                    child: LinearProgressIndicator(
                      minHeight: 2,
                      color: kAccent,
                      backgroundColor: kBorder,
                    ),
                  )
                : null,
          ),
          body: !hasSources
              ? EmptyState(
                  icon: Icons.live_tv_rounded,
                  title: 'Henüz liste yok',
                  message:
                      'Başlamak için kendi aboneliğinizin M3U bağlantısını '
                      'veya Xtream bilgilerinizi ekleyin.',
                  action: FilledButton.icon(
                    onPressed: _openSources,
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Liste ekle'),
                  ),
                )
              : Column(
                  children: [
                    _buildFilters(),
                    if (_library.status.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                _library.status,
                                style: const TextStyle(
                                    color: kTextDim, fontSize: 12),
                                maxLines: 2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    Expanded(
                      child: channels.isEmpty
                          ? const EmptyState(
                              icon: Icons.search_off_rounded,
                              title: 'Kanal bulunamadı',
                              message:
                                  'Aramayı veya kategori seçimini değiştirin.',
                            )
                          : ListView.builder(
                              itemCount: channels.length,
                              itemExtent: 68,
                              itemBuilder: (context, index) {
                                final channel = channels[index];
                                return ChannelTile(
                                  channel: channel,
                                  playing: channel.key == _library.lastChannelKey,
                                  onTap: () => _openChannel(channel),
                                );
                              },
                            ),
                    ),
                  ],
                ),
          floatingActionButton: (_library.lastChannel != null && hasSources)
              ? FloatingActionButton.extended(
                  backgroundColor: kAccent,
                  foregroundColor: const Color(0xFF12161B),
                  onPressed: () => _openChannel(_library.lastChannel!),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('Devam et'),
                )
              : null,
        );
      },
    );
  }

  Widget _buildFilters() {
    final groups = _library.groups;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: _library.setSearch,
                  textInputAction: TextInputAction.search,
                  decoration: InputDecoration(
                    hintText: 'Kanal ara',
                    prefixIcon: const Icon(Icons.search_rounded, size: 20),
                    suffixIcon: _library.searchText.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18),
                            onPressed: () {
                              _searchController.clear();
                              _library.setSearch('');
                            },
                          ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                isSelected: _library.favoritesOnly,
                icon: Icon(
                  _library.favoritesOnly
                      ? Icons.star_rounded
                      : Icons.star_outline_rounded,
                  color: _library.favoritesOnly ? kAccent : kTextDim,
                ),
                tooltip: 'Yalnızca favoriler',
                onPressed: () =>
                    _library.setFavoritesOnly(!_library.favoritesOnly),
              ),
            ],
          ),
        ),
        if (_library.sources.length > 1) _buildSourceRow(),
        if (groups.isNotEmpty)
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _groupChip('Tümü', ''),
                for (final group in groups) _groupChip(group, group),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildSourceRow() {
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: const Text('Tüm listeler'),
              selected: _library.activeSourceId == null,
              onSelected: (_) => _library.setActiveSource(null),
            ),
          ),
          for (final source in _library.sources)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(source.name),
                selected: _library.activeSourceId == source.id,
                onSelected: (_) => _library.setActiveSource(source.id),
              ),
            ),
        ],
      ),
    );
  }

  Widget _groupChip(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ChoiceChip(
        label: Text(label),
        selected: _library.groupFilter == value,
        onSelected: (_) => _library.setGroup(value),
      ),
    );
  }
}
