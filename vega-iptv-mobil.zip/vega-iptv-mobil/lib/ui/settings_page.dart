/// Ayarlar.

import 'package:flutter/material.dart';

import '../services/library.dart';
import 'theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _library = Library.instance;
  late final TextEditingController _userAgent =
      TextEditingController(text: _library.settings.userAgent);

  @override
  void dispose() {
    _userAgent.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    _library.settings.userAgent = _userAgent.text.trim().isEmpty
        ? 'VLC/3.0.20 LibVLC/3.0.20'
        : _userAgent.text.trim();
    await _library.save();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ayarlar kaydedildi')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = _library.settings;

    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        children: [
          SwitchListTile(
            value: settings.useHls,
            title: const Text('Xtream için HLS kullan'),
            subtitle: const Text(
              'Kanallar .m3u8 olarak istenir. Mobil ağlarda daha kararlıdır. '
              'Bazı paneller yalnızca .ts verir; kanallar açılmıyorsa kapatın.',
              style: TextStyle(fontSize: 12, color: kTextDim),
            ),
            onChanged: (value) async {
              setState(() => settings.useHls = value);
              await _library.save();
            },
          ),
          const Divider(height: 1),
          SwitchListTile(
            value: settings.backgroundAudio,
            title: const Text('Arka planda ses'),
            subtitle: const Text(
              'Ekran kapandığında ya da başka bir uygulamaya geçtiğinizde '
              'ses devam eder.',
              style: TextStyle(fontSize: 12, color: kTextDim),
            ),
            onChanged: (value) async {
              setState(() => settings.backgroundAudio = value);
              await _library.save();
            },
          ),
          const Divider(height: 1),
          SwitchListTile(
            value: settings.rememberLastChannel,
            title: const Text('Son kanalı hatırla'),
            onChanged: (value) async {
              setState(() => settings.rememberLastChannel = value);
              await _library.save();
            },
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Tarayıcı kimliği',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                const Text(
                  'Yalnızca bir HTTP başlığıdır. Bazı sağlayıcılar belirli bir '
                  'değer bekler; size bir değer verildiyse buraya yazın.',
                  style: TextStyle(fontSize: 12, color: kTextDim, height: 1.4),
                ),
                const SizedBox(height: 10),
                TextField(controller: _userAgent, autocorrect: false),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: _save,
                  child: const Text('Kaydet'),
                ),
              ],
            ),
          ),
          const Divider(height: 32),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: Text(
              'Vega IPTV 1.0.0\n\n'
              'Bu uygulama kanal listesi içermez. İzlediğiniz yayınların '
              'kaynağı ve yasallığı sizin sorumluluğunuzdadır.',
              style: TextStyle(fontSize: 12, color: kTextDim, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
