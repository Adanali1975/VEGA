/// Liste ekleme ve yonetme.

import 'package:flutter/material.dart';

import '../models/models.dart';
import '../services/library.dart';
import 'theme.dart';
import 'widgets.dart';

class SourcesPage extends StatefulWidget {
  const SourcesPage({super.key});

  @override
  State<SourcesPage> createState() => _SourcesPageState();
}

class _SourcesPageState extends State<SourcesPage> {
  final _library = Library.instance;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _library,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('Listelerim')),
          body: _library.sources.isEmpty
              ? const EmptyState(
                  icon: Icons.playlist_add_rounded,
                  title: 'Liste yok',
                  message:
                      'Aşağıdaki düğmeyle aboneliğinizin M3U bağlantısını '
                      'veya Xtream bilgilerini ekleyin. Bilgiler yalnızca '
                      'bu telefonda saklanır.',
                )
              : ListView.separated(
                  itemCount: _library.sources.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final source = _library.sources[index];
                    final count =
                        _library.channelsBySource[source.id]?.length ?? 0;
                    return ListTile(
                      title: Text(source.name),
                      subtitle: Text(
                        '${source.description}\n$count kanal',
                        style: const TextStyle(fontSize: 12, color: kTextDim),
                      ),
                      isThreeLine: true,
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'refresh') {
                            await _library.refreshSource(source);
                          } else if (value == 'delete') {
                            final ok = await _confirmDelete(source.name);
                            if (ok) await _library.removeSource(source.id);
                          }
                        },
                        itemBuilder: (context) => const [
                          PopupMenuItem(value: 'refresh', child: Text('Yenile')),
                          PopupMenuItem(value: 'delete', child: Text('Kaldır')),
                        ],
                      ),
                    );
                  },
                ),
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: kAccent,
            foregroundColor: const Color(0xFF12161B),
            onPressed: _showAddSheet,
            icon: const Icon(Icons.add_rounded),
            label: const Text('Liste ekle'),
          ),
        );
      },
    );
  }

  Future<bool> _confirmDelete(String name) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Listeyi kaldır'),
        content: Text('“$name” ve indirilen kanalları silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Kaldır'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  void _showAddSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => const _AddSourceSheet(),
    );
  }
}

class _AddSourceSheet extends StatefulWidget {
  const _AddSourceSheet();

  @override
  State<_AddSourceSheet> createState() => _AddSourceSheetState();
}

class _AddSourceSheetState extends State<_AddSourceSheet> {
  SourceKind _kind = SourceKind.m3u;

  final _name = TextEditingController();
  final _url = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _epg = TextEditingController();

  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _url.dispose();
    _username.dispose();
    _password.dispose();
    _epg.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final url = _url.text.trim();
    if (url.isEmpty) {
      setState(() => _error = _kind == SourceKind.m3u
          ? 'M3U bağlantısını girin.'
          : 'Sunucu adresini girin.');
      return;
    }
    if (_kind == SourceKind.m3u &&
        !url.startsWith('http://') &&
        !url.startsWith('https://')) {
      setState(() => _error = 'Bağlantı http:// veya https:// ile başlamalı.');
      return;
    }
    if (_kind == SourceKind.xtream &&
        (_username.text.trim().isEmpty || _password.text.isEmpty)) {
      setState(() => _error = 'Kullanıcı adı ve parolayı girin.');
      return;
    }

    final source = Source(
      id: DateTime.now().microsecondsSinceEpoch.toRadixString(16),
      name: _name.text.trim().isEmpty
          ? (_kind == SourceKind.xtream ? 'Xtream hesabı' : 'M3U listesi')
          : _name.text.trim(),
      kind: _kind,
      url: url,
      username: _username.text.trim(),
      password: _password.text,
      epgUrl: _epg.text.trim(),
    );

    Navigator.of(context).pop();
    await Library.instance.addSource(source);
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, bottom + 24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Liste ekle',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            SegmentedButton<SourceKind>(
              segments: const [
                ButtonSegment(
                  value: SourceKind.m3u,
                  label: Text('M3U bağlantısı'),
                ),
                ButtonSegment(
                  value: SourceKind.xtream,
                  label: Text('Xtream Codes'),
                ),
              ],
              selected: {_kind},
              onSelectionChanged: (value) =>
                  setState(() => _kind = value.first),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              decoration: const InputDecoration(hintText: 'Liste adı'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _url,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: InputDecoration(
                hintText: _kind == SourceKind.m3u
                    ? 'http://ornek.com/liste.m3u'
                    : 'http://sunucu.com:8080',
              ),
            ),
            if (_kind == SourceKind.xtream) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _username,
                autocorrect: false,
                decoration: const InputDecoration(hintText: 'Kullanıcı adı'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _password,
                obscureText: true,
                decoration: const InputDecoration(hintText: 'Parola'),
              ),
            ],
            const SizedBox(height: 10),
            TextField(
              controller: _epg,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                hintText: 'Yayın akışı (XMLTV) — isteğe bağlı',
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: kLive, fontSize: 13)),
            ],
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _submit,
              child: const Text('Ekle ve yükle'),
            ),
          ],
        ),
      ),
    );
  }
}
