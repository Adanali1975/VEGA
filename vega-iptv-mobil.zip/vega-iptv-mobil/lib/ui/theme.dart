/// Masaustu surumuyle ayni gorsel dil: koyu arduvaz zemin, kehribar vurgu.

import 'package:flutter/material.dart';

const Color kBackground = Color(0xFF0E1116);
const Color kPanel = Color(0xFF161B22);
const Color kPanelAlt = Color(0xFF1C232C);
const Color kBorder = Color(0xFF252D38);
const Color kText = Color(0xFFE6EDF3);
const Color kTextDim = Color(0xFF8B98A5);
const Color kAccent = Color(0xFFFFB020);
const Color kLive = Color(0xFFE5484D);

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: kBackground,
    colorScheme: base.colorScheme.copyWith(
      primary: kAccent,
      secondary: kAccent,
      surface: kPanel,
      onPrimary: const Color(0xFF12161B),
      onSurface: kText,
      error: kLive,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kPanel,
      foregroundColor: kText,
      elevation: 0,
      centerTitle: false,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: kPanel,
      surfaceTintColor: Colors.transparent,
    ),
    dialogTheme: const DialogThemeData(
      backgroundColor: kPanel,
      surfaceTintColor: Colors.transparent,
    ),
    cardTheme: const CardThemeData(
      color: kPanelAlt,
      surfaceTintColor: Colors.transparent,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kPanelAlt,
      hintStyle: const TextStyle(color: kTextDim),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kAccent),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: kAccent,
        foregroundColor: const Color(0xFF12161B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: kPanelAlt,
      selectedColor: kAccent,
      side: const BorderSide(color: kBorder),
      labelStyle: const TextStyle(color: kText, fontSize: 13),
      secondaryLabelStyle: const TextStyle(color: Color(0xFF12161B)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    listTileTheme: const ListTileThemeData(
      iconColor: kTextDim,
      textColor: kText,
    ),
    dividerTheme: const DividerThemeData(color: kBorder, thickness: 1),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: kPanelAlt,
      contentTextStyle: TextStyle(color: kText),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
