/// Oynatma ekrani.
///
/// Goruntuyu libmpv (media_kit) cozer; bu sayede HLS'in yani sira ham
/// MPEG-TS akislari da acilir. iOS'un yerlesik oynaticisi ham TS acamaz.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../models/models.dart';
import '../services/library.dart';
import 'theme.dart';
import 'widgets.dart';

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key, required this.channel});

  final Channel channel;

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final Player _player;
  late final VideoController _controller;

  final _library = Library.instance;
  final List<StreamSubscription<dynamic>> _subscriptions = [];

  late Channel _channel;
  bool _controlsVisible = true;
  bool _buffering = true;
  bool _fullscreen = false;
  String? _error;
  Timer? _hideTimer;

  @override
  void initState() {
    super.initState();
    _channel = widget.channel;

    _player = Player(
      configuration: const PlayerConfiguration(title: 'Vega IPTV'),
    );
    _controller = VideoController(_player);

    _subscriptions.add(_player.stream.buffering.listen((value) {
      if (mounted) setState(() => _buffering = value);
    }));
    _subscriptions.add(_player.stream.error.listen((message) {
      if (mounted) setState(() => _error = _explain(message));
    }));

    WakelockPlus.enable();
    _open(_channel);
    _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    for (final subscription in _subscriptions) {
      subscription.cancel();
    }
    _player.dispose();
    WakelockPlus.disable();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _open(Channel channel) async {
    setState(() {
      _channel = channel;
      _error = null;
      _buffering = true;
    });
    _library.rememberChannel(channel);
    await _player.open(
      Media(
        channel.url,
        httpHeaders: {'User-Agent': _library.settings.userAgent},
      ),
    );
  }

  String _explain(String message) {
    final text = message.toLowerCase();
    if (text.contains('404')) {
      return 'Yayın bulunamadı (404). Kanal kaldırılmış olabilir.';
    }
    if (text.contains('403')) {
      return 'Sunucu erişimi reddetti (403). Aboneliğiniz geçersiz olabilir.';
    }
    if (text.contains('timed out') || text.contains('timeout')) {
      return 'Sunucu yanıt vermedi. Bağlantınızı kontrol edin.';
    }
    return 'Yayın açılamadı. Başka bir kanal deneyebilirsiniz.';
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _controlsVisible = false);
    });
  }

  void _toggleControls() {
    setState(() => _controlsVisible = !_controlsVisible);
    if (_controlsVisible) _scheduleHide();
  }

  Future<void> _toggleFullscreen() async {
    setState(() => _fullscreen = !_fullscreen);
    if (_fullscreen) {
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  List<Channel> get _siblings => _library.visibleChannels;

  void _step(int delta) {
    final list = _siblings;
    if (list.isEmpty) return;
    var index = list.indexWhere((c) => c.key == _channel.key);
    if (index < 0) index = 0;
    final next = list[(index + delta) % list.length];
    _open(next);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_fullscreen,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _fullscreen) _toggleFullscreen();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          top: !_fullscreen,
          bottom: !_fullscreen,
          child: Column(
            children: [
              Expanded(
                flex: _fullscreen ? 1 : 0,
                child: _buildVideoArea(),
              ),
              if (!_fullscreen) Expanded(child: _buildChannelList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoArea() {
    final video = Video(
      controller: _controller,
      controls: NoVideoControls,
      fit: BoxFit.contain,
    );

    return GestureDetector(
      onTap: _toggleControls,
      onDoubleTap: _toggleFullscreen,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            color: Colors.black,
            width: double.infinity,
            // Dikeyken 16:9 kutu, tam ekranda mevcut alanin tamami
            child: _fullscreen
                ? video
                : AspectRatio(aspectRatio: 16 / 9, child: video),
          ),
          if (_buffering && _error == null)
            const CircularProgressIndicator(color: kAccent, strokeWidth: 2.5),
          if (_error != null) _buildError(),
          if (_controlsVisible) _buildControls(),
        ],
      ),
    );
  }

  Widget _buildError() {
    return Container(
      color: Colors.black87,
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline_rounded, color: kLive, size: 36),
          const SizedBox(height: 12),
          Text(
            _error!,
            textAlign: TextAlign.center,
            style: const TextStyle(color: kText),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () => _open(_channel),
            child: const Text('Yeniden dene'),
          ),
        ],
      ),
    );
  }

  Widget _buildControls() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withValues(alpha: 0.65),
              Colors.transparent,
              Colors.black.withValues(alpha: 0.75),
            ],
            stops: const [0, 0.45, 1],
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                  onPressed: () {
                    if (_fullscreen) {
                      _toggleFullscreen();
                    } else {
                      Navigator.of(context).pop();
                    }
                  },
                ),
                Expanded(
                  child: Text(
                    _channel.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    _library.isFavorite(_channel)
                        ? Icons.star_rounded
                        : Icons.star_outline_rounded,
                    color: _library.isFavorite(_channel) ? kAccent : Colors.white,
                  ),
                  onPressed: () async {
                    await _library.toggleFavorite(_channel);
                    setState(() {});
                  },
                ),
              ],
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  iconSize: 32,
                  icon: const Icon(Icons.skip_previous_rounded, color: Colors.white),
                  onPressed: () => _step(-1),
                ),
                const SizedBox(width: 8),
                IconButton(
                  iconSize: 46,
                  icon: Icon(
                    _player.state.playing
                        ? Icons.pause_circle_filled_rounded
                        : Icons.play_circle_filled_rounded,
                    color: Colors.white,
                  ),
                  onPressed: () async {
                    await _player.playOrPause();
                    setState(() {});
                  },
                ),
                const SizedBox(width: 8),
                IconButton(
                  iconSize: 32,
                  icon: const Icon(Icons.skip_next_rounded, color: Colors.white),
                  onPressed: () => _step(1),
                ),
              ],
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              child: Row(
                children: [
                  const Icon(Icons.circle, color: kLive, size: 9),
                  const SizedBox(width: 6),
                  const Text('CANLI',
                      style: TextStyle(color: Colors.white70, fontSize: 11)),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.tv_rounded, color: Colors.white),
                    tooltip: 'TV’de izleme',
                    onPressed: _showCastHelp,
                  ),
                  IconButton(
                    icon: Icon(
                      _fullscreen
                          ? Icons.fullscreen_exit_rounded
                          : Icons.fullscreen_rounded,
                      color: Colors.white,
                    ),
                    onPressed: _toggleFullscreen,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCastHelp() {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('TV’de izleme',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            const Text(
              'Ekranın sağ üstünden aşağı kaydırıp Denetim Merkezi’ni açın, '
              'Ekran Yansıtma’ya dokunun ve Apple TV ya da AirPlay destekli '
              'televizyonunuzu seçin. Görüntü ve ses TV’ye aktarılır.',
              style: TextStyle(color: kTextDim, height: 1.5),
            ),
            const SizedBox(height: 12),
            const Text(
              'Not: Bu yöntem tüm ekranı yansıtır. Uygulama içinden doğrudan '
              'AirPlay seçici ve Chromecast desteği henüz yok.',
              style: TextStyle(color: kTextDim, fontSize: 12, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChannelList() {
    return AnimatedBuilder(
      animation: _library,
      builder: (context, _) {
        final channels = _siblings;
        if (channels.isEmpty) {
          return const SizedBox.shrink();
        }
        return Container(
          color: kBackground,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 14, 16, 6),
                child: Text('Kanallar',
                    style: TextStyle(color: kTextDim, fontSize: 12)),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: channels.length,
                  itemExtent: 68,
                  itemBuilder: (context, index) {
                    final channel = channels[index];
                    return ChannelTile(
                      channel: channel,
                      playing: channel.key == _channel.key,
                      onTap: () => _open(channel),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
