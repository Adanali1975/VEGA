/// Vega IPTV - iOS ve Android yayin oynatici.

import 'package:audio_session/audio_session.dart';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';

import 'services/library.dart';
import 'ui/home_page.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // libmpv'yi baslatir. Kitaplik uygulamayla birlikte gelir; telefona
  // ayrica bir oynatici kurulmasi gerekmez.
  MediaKit.ensureInitialized();

  await _configureAudioSession();
  await Library.instance.load();

  runApp(const VegaApp());
}

/// Ses oturumunu "calma" kipine alir.
///
/// iOS'ta bu yapilmazsa sessiz anahtari acikken ses gelmez ve ekran
/// kapandiginda oynatma durur. Arka planda calmaya devam etmesi icin
/// ayrica Info.plist icinde UIBackgroundModes -> audio gerekir; bunu
/// tool/patch_ios.sh ekler.
Future<void> _configureAudioSession() async {
  try {
    final session = await AudioSession.instance;
    await session.configure(AudioSessionConfiguration.music());
    await session.setActive(true);
  } catch (_) {
    // Ses oturumu kurulamazsa oynatma yine de denenir
  }
}

class VegaApp extends StatelessWidget {
  const VegaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vega IPTV',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomePage(),
    );
  }
}
