#!/usr/bin/env bash
# iOS projesine uygulamaya ozgu ayarlari ekler.
#
# ios/ klasoru depoda tutulmaz; "flutter create" ile uretilir, sonra bu
# betik calisir. Boylece Xcode proje dosyalarini elle tasimak gerekmez.

set -euo pipefail

PLIST="ios/Runner/Info.plist"
PB="/usr/libexec/PlistBuddy"

if [ ! -f "$PLIST" ]; then
  echo "HATA: $PLIST bulunamadi. Once 'flutter create --platforms=ios .' calistirin."
  exit 1
fi

echo "iOS ayarlari uygulaniyor..."

# 1) http yayinlara izin ver.
#    IPTV saglayicilarinin cogu duz http kullanir; bu anahtar olmadan
#    iOS baglantilari engeller ve hicbir kanal acilmaz.
$PB -c "Delete :NSAppTransportSecurity" "$PLIST" 2>/dev/null || true
$PB -c "Add :NSAppTransportSecurity dict" "$PLIST"
$PB -c "Add :NSAppTransportSecurity:NSAllowsArbitraryLoads bool true" "$PLIST"

# 2) Ekran kapaliyken ses devam etsin.
$PB -c "Delete :UIBackgroundModes" "$PLIST" 2>/dev/null || true
$PB -c "Add :UIBackgroundModes array" "$PLIST"
$PB -c "Add :UIBackgroundModes:0 string audio" "$PLIST"

# 3) Gorunen ad ve yatay ekran destegi.
$PB -c "Set :CFBundleDisplayName Vega IPTV" "$PLIST" 2>/dev/null \
  || $PB -c "Add :CFBundleDisplayName string Vega IPTV" "$PLIST"

$PB -c "Delete :UISupportedInterfaceOrientations" "$PLIST" 2>/dev/null || true
$PB -c "Add :UISupportedInterfaceOrientations array" "$PLIST"
$PB -c "Add :UISupportedInterfaceOrientations:0 string UIInterfaceOrientationPortrait" "$PLIST"
$PB -c "Add :UISupportedInterfaceOrientations:1 string UIInterfaceOrientationLandscapeLeft" "$PLIST"
$PB -c "Add :UISupportedInterfaceOrientations:2 string UIInterfaceOrientationLandscapeRight" "$PLIST"

echo "iOS ayarlari tamam."
