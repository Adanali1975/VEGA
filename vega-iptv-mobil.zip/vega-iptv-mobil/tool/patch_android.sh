#!/usr/bin/env bash
# Android projesine internet izni ve http destegi ekler.

set -euo pipefail

MANIFEST="android/app/src/main/AndroidManifest.xml"

if [ ! -f "$MANIFEST" ]; then
  echo "HATA: $MANIFEST bulunamadi. Once 'flutter create --platforms=android .' calistirin."
  exit 1
fi

echo "Android ayarlari uygulaniyor..."

# 1) Internet izni
if ! grep -q "android.permission.INTERNET" "$MANIFEST"; then
  sed -i.bak 's|</manifest>|    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>|' "$MANIFEST"
  rm -f "$MANIFEST.bak"
fi

# 2) Duz http yayinlara izin ver (IPTV saglayicilarinin cogu https kullanmaz)
if ! grep -q "usesCleartextTraffic" "$MANIFEST"; then
  sed -i.bak 's|<application|<application\n        android:usesCleartextTraffic="true"|' "$MANIFEST"
  rm -f "$MANIFEST.bak"
fi

# 3) Uygulama adi
sed -i.bak 's|android:label="[^"]*"|android:label="Vega IPTV"|' "$MANIFEST"
rm -f "$MANIFEST.bak"

echo "Android ayarlari tamam."
